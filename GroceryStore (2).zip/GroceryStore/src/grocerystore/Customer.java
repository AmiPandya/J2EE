/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grocerystore;

    public class Customer implements Comparable<Customer> {

    private Integer itemCount; //used the wrapper in order to support compareTo function
    private Type type;
    private boolean inService;
    private int timeArrived;
    
    
    public Customer(Type type,int timeArrived,Integer itemCount) {
        this.type=type;
        this.timeArrived=timeArrived;
        this.itemCount=itemCount;
    }

    public int getItemCount() {
        return itemCount;
    }

    public void setItemCount(int itemCount) {
        this.itemCount = itemCount;
    }

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }

    public boolean isInService() {
        return inService;
    }

    public void setInService(boolean inService) {
        this.inService = inService;
    }

    public int getTimeArrived() {
        return timeArrived;
    }

    public void setTimeArrived(int registerArrived) {
        this.timeArrived = registerArrived;
    }

    public Integer servedItems(){
        return --this.itemCount;
    }
    /**
     * 
     * @param {@link Customer}
     * @return int
     *  comparing the customers based on their item counts, if that is same
     *  comparing them according to their type.
     */
    @Override
    public int compareTo(Customer o) {
        int val = 0;
            val = this.itemCount.compareTo(o.itemCount);
        if (val == 0) {
            val = this.type.compareTo(o.type);
        }
        return val;
    }

}
enum Type {
    A, B;
}

    

