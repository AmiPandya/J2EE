var gulp = require('gulp');
var mocha = require('gulp-mocha');
var babel = require('babel-register');

gulp.task('test', function() {
  return gulp.src(['test/**/*.js'])
    .pipe(mocha({
      compilers: babel
  }));
});

gulp.task('tdd', function() {
  return gulp.watch(['src/**/*.js', 'test/**/*.js'], ['test']);
});

gulp.task('tdd-single', function() {
return gulp.watch('test/*.js')
  .on('change', function(file) {
    gulp.src(file.path)
      .pipe(mocha({
        compilers: babel
      }))
  });
});
