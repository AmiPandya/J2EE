# Public / Private API - Submission Global

## Security
**Protocals**

1. JWT Authentication:
  - The application requires Bearer Authentication schema defined in HTTP to protect against CSRF attacks and a JWT token is expected to be found in the Authorization HTTP header. By default the application decodes the token isolating the User ID and checks to see if the user is found in the database. This authentication handshake is required for every request made to the private API.

2. Helmet:
  - Helmet helps secure Express applications by setting various HTTP headers. It's not a silver bullet, but it can help!
  - https://www.npmjs.com/package/helmet

3. TODO:
  - Setup HTTPS.