'use strict';

const Sequelize = require('sequelize');
const appConfig = require('../config')();

const fs = require('fs');
const path = require('path');
const basename = path.basename(module.filename);
const dbConfig = appConfig.DB_CONFIG;

let db = {};

if (appConfig) {
  const postgresUrl = appConfig.DB_NAME;
  const sequelize = new Sequelize(
    postgresUrl,
    appConfig.DB_USERNAME,
    appConfig.DB_PASSWORD,
    dbConfig
  );

  fs.readdirSync(__dirname + '/models')
    .filter(function(file) {
      return (file.indexOf('.') !== 0) && (file !== basename) && (file.slice(-3) === '.js');
    })
    .forEach(function(file) {
      let model = sequelize['import'](path.join(__dirname + '/models/', file));
      db[model.name] = model;
    });

  Object.keys(db).forEach((modelName)  => {
    if (db[modelName].options.hasOwnProperty('associate')) {
      db[modelName].options.associate(db);
    }
  });

  db.sequelize = sequelize;
  db.Sequelize = Sequelize;
}

module.exports = db;
