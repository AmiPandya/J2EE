'use strict';

const ORM = require('sequelize');

module.exports = function(sequelize) {
  let SamplePrivate = sequelize.define("SamplePrivate", {
    name: ORM.STRING,
    description: ORM.STRING
  });

  return SamplePrivate;
}
