'use strict';

const ORM = require('sequelize');

module.exports = function(sequelize) {
  let SamplePublic = sequelize.define("SamplePublic", {
    name: ORM.STRING,
    description: ORM.STRING
  });
  
  return SamplePublic;
}
