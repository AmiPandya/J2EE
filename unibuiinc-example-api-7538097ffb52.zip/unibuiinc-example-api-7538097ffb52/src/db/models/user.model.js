'use strict';

const bcrypt = require('bcrypt-nodejs');
const ORM = require('sequelize');

module.exports = function(sequelize) {

  let User = sequelize.define('User', {
    email: ORM.STRING,
    password: ORM.STRING,
    accountVerified: {
      type: ORM.INTEGER,
      defaultValue: 0
    },
    uuid: {
      type: ORM.UUID,
      defaultValue: ORM.UUIDV1,
      primaryKey: true
    }
  }, {

    classMethods: {
      hashPassword: function(password) {
        return bcrypt.hashSync(password, bcrypt.genSaltSync(8), null);
      }
    },
    instanceMethods: {
      validPassword: function(password) {
        return bcrypt.compareSync(password, this.password);
      }
    }
  });

  return User;
};
