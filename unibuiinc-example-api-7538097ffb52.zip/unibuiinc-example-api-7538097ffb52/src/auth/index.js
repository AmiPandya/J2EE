'use strict';

import fs from 'fs';
import path from 'path';

module.exports = (models, services, passport) => {
  fs.readdirSync(__dirname + '/strategies')
    .forEach(function(file) {
      let segments = file.split('.');
      let strategy = segments[0];

      let fn = require(path.join(__dirname + '/strategies/' + file));
      fn(models, services, passport);
    });
};