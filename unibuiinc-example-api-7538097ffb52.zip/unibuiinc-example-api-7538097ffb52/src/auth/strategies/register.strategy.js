'use strict';

import LocalStrategyModule from 'passport-local';
const LocalStrategy = LocalStrategyModule.Strategy;

var options = {
  usernameField: 'email'
};

module.exports = (models, services, passport) => {
  passport.use('register', new LocalStrategy(options, (email, password, done) => {
    return services.RegisterService.findOrCreate(email, password, done);
  }));
};
