'use strict';

import jwt from 'jsonwebtoken';

import JWTBearerStrategyModule from 'passport-http-bearer';
const JWTBearerStrategy = JWTBearerStrategyModule.Strategy;

import appConfigModule from '../../config';
const appConfig = appConfigModule();

module.exports = (models, services, passport) => {
  passport.use('jwt-bearer', new JWTBearerStrategy(
    appConfig.SESSION_SECRET, (token, done) => {
      let decoded = jwt.verify(token, appConfig.SESSION_SECRET);

      return services.JWTBearerService.findById(decoded.uuid, token, done);
    })
  );
};
