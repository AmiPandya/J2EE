'use strict';

import LocalStrategyModule from 'passport-local';
const LocalStrategy = LocalStrategyModule.Strategy;

var options = {
  usernameField: 'email',
  passwordField: 'password'
};

module.exports = (models, services, passport) => {
  passport.use('login', new LocalStrategy(options, (email, password, done) => {
    return services.LoginService.findOne(email, password, done);
  }));
};
