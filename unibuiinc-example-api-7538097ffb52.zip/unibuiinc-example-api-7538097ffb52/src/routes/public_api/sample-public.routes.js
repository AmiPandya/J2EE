'use strict';

import express from 'express';

module.exports = (service) => {
  let router = express.Router();

  router.route('/')
  
    .post((req, res) => {
      let name = req.body.name;
      let description = req.body.description;

      return service.create(name, description)
        .then((sample) => {
          res.json({ sample: sample });
        });
    })

    .get((req, res) => {
      return service.getAll()
        .then((samples) => {
          res.json(samples);
        });
    });

  return router;
}
