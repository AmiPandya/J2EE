'use strict';

import express from 'express';
import LocalStrategyModule from 'passport-local';

import { Logger } from '../../utils';

let LocalStrategy = LocalStrategyModule.Strategy;

import jwt from 'jsonwebtoken';
import appConfigModule from '../../config';
const appConfig = appConfigModule();

module.exports = (services, passport) => {
  let router = express.Router();

  router.post('/', (req, res, next) => {
    passport.authenticate('login', (error, user, info) => {

      if (error) {
        Logger.error('Login Route: ', error);
        return next(error);
      }

      if (!user) {
        return res.json({
          success: false,
          message: info.message
        });
      }

      let token = jwt.sign({ uuid: user.uuid }, appConfig.SESSION_SECRET);

      res.json({
        email: user.email,
        token: token,
        success: true,
        message: 'Successful Login!'
      });

    })(req, res, next);
  });

  return router;
};
