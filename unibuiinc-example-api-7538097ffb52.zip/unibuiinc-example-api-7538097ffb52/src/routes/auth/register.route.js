'use strict';

import express from 'express';
import LocalStrategyModule from 'passport-local';

import { Logger } from '../../utils';

let LocalStrategy = LocalStrategyModule.Strategy;

import jwt from 'jsonwebtoken';
import appConfigModule from '../../config';
const appConfig = appConfigModule();

module.exports = (services, passport) => {
  let router = express.Router();

  router.post('/', (req, res, next) => {
    passport.authenticate('register', (error, user, info) => {

      if (error) {
        Logger.error('Register Route: ', error);
        return next(error);
      }

      // Returns false user if the email was already found in the database.
      if (!user) {
        return res.json({
          email: info.email,
          message: info.message,
          success: false,
        });
      }

      // Returns newly created user object.
      if (user) {
        services.EmailVerification.send(user.email);

        res.json({
          success: true
        });
      }

    })(req, res, next);
  });

  router.get('/verifyEmail', services.EmailVerification.emailResponseHandler);

  return router;
};
