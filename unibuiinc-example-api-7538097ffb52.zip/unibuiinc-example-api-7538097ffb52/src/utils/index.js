'use strict';

import { Logger, LoggerInstance, transports } from 'winston';
import { Response, Request, RequestHandler } from 'express';
import root from 'app-root-path';

import appConfigModule from '../config';
let appConfig = appConfigModule();

const customLevels = {
  levels: {
    debug: 5,
    info: 4,
    warn: 3,
    error: 2,
    fatal: 1,
    always: 0,
  },
  colors: {
    always: 'magenta',
  }
};

/**
 * Logger Setup:
 * instantiates Logger class for application wide use.
 */
const logger = new Logger({
  transports: [
      new transports.Console({
        level: appConfig.LOG_LEVEL_CONSOLE,
        handleExceptions: true,
        json: appConfig.LOG_IN_JSON,
        colorize: true,
        timestamp: true,
      }),
      new transports.File({
        filename: root + '/src/log/error.log',
        level: appConfig.LOG_LEVEL_FILE
      })
    ],
  exitOnError: false,
  levels: customLevels.levels,
  colors: customLevels.colors,
});

/**
 * Logger Middleware:
 * used to capture data from incomming requests.
 */
const loggerMiddleware = (logger) => {
  const url = require('url');
  const events = require('events');

  return (req, res, next) => {
    let requestEnd = res.end;
    let requestedUrl = url.parse(req.originalUrl);
    let startTime = new Date();
    let userAgent = req.get('User-Agent');

    res.end = (chunk , encoding ) => {
      let time  = new Date();
      let data = {
        'statusCode': res.statusCode,
        'method': req.method,
        'responseTime': time.getTime() - startTime.getTime(),
        'url': req.originalUrl,
        requestedUrl,
        'ip': req.headers['x-forwarded-for'] || req.ip,
        'userAgent': userAgent
      };

      res.end = requestEnd;
      res.end(chunk, encoding);
      logger.info('', data);
    };

    next();
  };
};

export {
  logger as Logger,
  loggerMiddleware as LoggerMiddleware,
};
