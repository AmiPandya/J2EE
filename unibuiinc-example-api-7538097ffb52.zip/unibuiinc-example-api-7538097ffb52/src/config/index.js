'use strict';

const dotenv = require('dotenv').config();
const configurations = require('./config.json');

module.exports = () => {
  let config = {};
  let env = process.env.ENVIRONMENT;

  for (let property in configurations) {
    if (configurations.hasOwnProperty(property)) {
      if (property === env) {
        config = configurations[property];
      }
    }
  }

  return config;
};
