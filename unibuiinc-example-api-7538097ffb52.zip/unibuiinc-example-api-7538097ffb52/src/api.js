'use strict';

import express from 'express';
import http from 'http';

import bodyParser from 'body-parser';
import cookieParser from 'cookie-parser';
import cors from 'cors';
import fs from 'fs';
import helmet from 'helmet';
import morgan from 'morgan';
import path from 'path';
import passport from 'passport';
import session from 'express-session';


// API Config ======================
// =================================
import appConfigModule from './config';
const appConfig = appConfigModule();
const ENV = appConfig.NODE_ENV;
const PORT = appConfig.PORT;

let dev = ENV === 'development';
let pro = ENV === 'production';

// Utils: logging
import { Logger, LoggerMiddleware } from './utils';

// Models ==========================
// =================================
import models from './db';

// Auth Configurations =============
// =================================
import authConfigurations from './auth';

// Database Services ===============
// =================================
import services from './services';

// Application Routes ==============
// =================================
/* Authentication */
import authGenRegisterRouter from './routes/auth/register.route';
import authGenLoginRouter from './routes/auth/login.route';
/* API Public */
import sampleGenPublicRouter from './routes/public_api/sample-public.routes';
/* API Private */
import sampleGenPrivateRouter from './routes/private_api/sample-private.routes';

// Express Application
const app = express();
const server = http.createServer(app);

// Middleware ======================
// =================================
/**
 * Helmet: HTTP Headers Security
 * https://www.npmjs.com/package/helmet
 */
app.use(helmet());
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookieParser());
// JWT Handles authentication...
app.use(session({
  secret: appConfig.SESSION_SECRET,
  resave: true,
  saveUninitialized: true
}));

// Logger Middleware !! KEEP BELOW OTHER MIDDLEWARE !!
if (dev) {
  app.use(LoggerMiddleware(Logger));
  app.use(morgan('dev'));
}

if (pro) {
  let accessLogStream = fs.createWriteStream(path.join('./log', 'access.log'), {flags: 'a'})
  app.use(morgan('combined', { stream: accessLogStream }))
}

// Sequelize CB ====================
// =================================
models.sequelize.sync()
  .then(() => {
    authConfigurations(models, services, passport);
    app.use(passport.initialize());
    app.use(passport.session());

    // API Routers
    let auth = express.Router();
    let publicAPI = express.Router();
    let privateAPI = express.Router();

    // Set Application Routers
    /* Authentication */
    let authRegisterRouter = authGenRegisterRouter(services, passport);
    let authLoginRouter = authGenLoginRouter(services, passport);
    /* API Public */
    let samplePublicRouter = sampleGenPublicRouter(services.SamplePublicService);
    /* API Private */
    let samplePrivateRouter = sampleGenPrivateRouter(services.SamplePrivateService);

    // Set Routes
    /* Authentication */
    auth.use('/register', authRegisterRouter);
    auth.use('/login', authLoginRouter);
    /* API Public */
    publicAPI.use('/sample-public', samplePublicRouter);
    /* API Private */
    privateAPI.use('/sample-private', samplePrivateRouter);

    /* Authentication Routers */
    app.use('/auth', auth);
    /* Public API Routers */
    app.use('/pub-api', publicAPI);
    /* Private API Routers */
    app.use('/api', [passport.authenticate('jwt-bearer', {
      session: false,
      failWithError: true
    }), (err, req, res, next) => {

      if (err) {
        Logger.error('Authentication Handshake: ', err);
        let error = {
          error: err.name,
          message: err.message
        };
        let statusCode = err.status || 500;
        res.status(statusCode).json(error);
      }
      return next();
    }], privateAPI);
  });

// Run Server ======================
// =================================
server.listen(PORT, () => {
  Logger.info('Environment:', appConfig.NODE_ENV);
  Logger.info('Listening on port: ' + server.address().port);

  // Error Test
  Logger.error('broken');
});
