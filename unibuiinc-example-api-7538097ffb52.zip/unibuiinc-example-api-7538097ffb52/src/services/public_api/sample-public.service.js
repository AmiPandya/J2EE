'use strict';

class SamplePrivateService  {

  constructor(models) {
    this.models = models;
  }

  create(name, description) {
    return this.models.SamplePrivate.create({
      name: name,
      description: description
    })
    .then((sample) => {
      return sample
    });
  }

  getAll() {
    return this.models.SamplePrivate.findAll()
      .then((samples) => {
        return samples;
      });
  }
}

module.exports = SamplePrivateService;
