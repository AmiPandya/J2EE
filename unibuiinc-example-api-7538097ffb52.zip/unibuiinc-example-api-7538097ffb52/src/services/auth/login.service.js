'use strict';

import { Logger } from '../../utils';

class LoginService {

  constructor(models) {
    this.models = models;
  }

  findOne(email, password, done) {
    let cachedEmail = email;

    this.models.User
      .findOne({
        where: { 'email': email.toLowerCase() }
      })
      .then((user) => {
        if (!user) {
          return done(null, false, {
            email: cachedEmail,
            message: `Email ${cachedEmail} does not exists.`
          });
        }

        if (!user.validPassword(password)) {
          return done(null, false, {
            email: cachedEmail,
            message: 'Email or password does not match.'
          });
        }

        done(null, user);
      })
      .catch((error) => {
        Logger.erro('Login Service: ', error);
      });
  }
}

module.exports = LoginService;
