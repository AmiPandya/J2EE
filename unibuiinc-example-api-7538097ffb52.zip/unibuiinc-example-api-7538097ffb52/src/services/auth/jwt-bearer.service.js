'use strict';

import { Logger } from '../../utils';

class JWTBearerService {

  constructor(models) {
    this.models = models;
  }

  findById(id, token, done) {
    this.models.User
      .findById(id)
      .then((user) => {
        if (!user) {
          return done(null, false);
        }
        return done(null, user, token);
      })
      .catch((error) => {
        Logger.error('JWT Bearer Service: ', error);

        return done(error);
      });
  }
}

module.exports = JWTBearerService;
