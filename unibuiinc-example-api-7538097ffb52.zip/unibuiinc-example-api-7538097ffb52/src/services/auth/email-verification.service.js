'use strict';

import _ from 'underscore';
import fs from 'fs';
import jwt from 'jsonwebtoken';
import nodemailer from 'nodemailer';
import mailgun from 'nodemailer-mailgun-transport';

import appConfigModule from '../../config';
const appConfig = appConfigModule();

class EmailVerification {

  constructor(models) {
    this.models = models;
    this.emailResponseHandler = this.emailResponseHandler.bind(this);
  }

  send(email) {
    let payload = { email: email };
    let token = jwt.sign(payload, appConfig.SESSION_SECRET);

    let auth = {
      auth: {
        api_key: appConfig.MAILGUN_API_KEY,
        domain: appConfig.MAILGUN_DOMAIN
      }
    };

    let transporter = nodemailer.createTransport(mailgun(auth));

    transporter.sendMail({
      from: appConfig.EMAIL_TEMPLATE.from,
      to: email,
      subject: appConfig.EMAIL_TEMPLATE.subject,
      html: this.templateHTML(token)
    }, (error, info) => {
      if (error) {
        console.log('error', error);
      } else {
        console.log('Email sent: ' + info);
      }
    });
  }

  emailResponseHandler(req, res) {
    let token = req.query.token;
    let payload = jwt.verify(token, appConfig.SESSION_SECRET);
    let email = payload.email;

    this.models.User.findOne({
      where: { email: email }
    })
    .then((user) => {
      if (user) {
        user.update({
          accountVerified: 1
        });
        // TODO: Redirect to Login...
        // TODO: Auto Login...
        // return res.redirect();
        res.json('worked.');
      }
    })
    .catch(() => {
      handleError(res);
    });

  }

  templateHTML(token) {
    let model = { verifyUrl: appConfig.API_URL + 'auth/register/verifyEmail?token=' };
    let path = './src/views/email.template.html';
    var encoding = 'utf8';
    var html = fs.readFileSync(path, encoding);
    var template = _.template(html);

    model.verifyUrl += token;

    return template(model);
  }

  handleError(response) {
    // TODO: Redirect...
  }
}

_.templateSettings = {
  interpolate: /\{\{(.+?)\}\}/g
};

module.exports = EmailVerification;
