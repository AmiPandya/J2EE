'use strict';

class RegisterService {

  constructor(models) {
    this.models = models;
  }

  findOrCreate(email, password, done) {
    let cachedEmail = email;

    this.models.User
      .findOrCreate({
        where: { email: email },
        defaults: {
          password: this.models.User.hashPassword(password)
        }
      })
      .spread(function(user, created) {
        if (!created) {
          return done(null, false, {
            email: cachedEmail,
            message: `Email ${cachedEmail} already exists.`
          });
        }
        done(null, user);
      });
  }
}

module.exports = RegisterService;
