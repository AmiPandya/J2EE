'use strict';

class SamplePublicService  {

  constructor(models) {
    this.models = models
  }

  create(name, description) {
    return this.models.SamplePublic.create({
      name: name,
      description: description
    })
    .then((sample) => {
      return sample
    });
  }

  getAll() {
    return this.models.SamplePublic.findAll()
      .then((samples) => {
        return samples;
      });
  }
}

module.exports = SamplePublicService;
