'use strict';

import recursiveReadSync from 'recursive-readdir-sync';
import models from '../db';
import path from 'path';

const basename = path.basename(module.filename);
const services = {};

let files = [];

try {
  files = recursiveReadSync(__dirname);
  files = files
    .filter((file) => {
      let fl = path.basename(file);
      return (fl.indexOf('.') !== 0) && (fl !== basename) && (fl.slice(-3) === '.js');
    })
    .forEach((file) => {
      let service = require(file);
      services[service.name] = new service(models);
    });
} catch (err) {
  if (err.errno === 34) {
    // TODO: error handling for - path does not exist...
  } else {
    // TODO: error handling for - something unrelated went wrong...
    throw err;
  }
}

module.exports = services;
