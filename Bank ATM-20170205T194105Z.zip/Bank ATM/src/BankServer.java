import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;


public class BankServer {

	public static void main(String arg[]){
		
		try {
			int balance = 5000;
			ServerSocket serverSocket = new ServerSocket(3556);
			Socket sc = serverSocket.accept();
			
			Scanner scanner = new Scanner(sc.getInputStream());
			int userOption= scanner.nextInt();
			
			PrintStream ps = new PrintStream(sc.getOutputStream());
			if(userOption ==1){
				ps.println("Your Current balance is : "+balance);
			}
			else if(userOption==2){
				int withdrawAmt = scanner.nextInt();
				if(withdrawAmt>balance){
					ps.println("Sorry, You do not have sufficient balance.");
				}
				else{
					balance = balance-withdrawAmt;
					ps.println("Transaction completed. Available banalce is : "+balance);
				}
			}
			else if (userOption==3){
				int depositAmt = scanner.nextInt();
				balance = balance+depositAmt;
				ps.println("Deposit Successfully completed.Available balance is : " +balance);
			}
			else if(userOption==4) {
				ps.println("Exit successfully.");
			}
			else{
				ps.println("Invalid Input.");
			}
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
