import java.io.PrintStream;
import java.net.Socket;
import java.util.Scanner;

public class BankClient {

	public static void main(String ar[]){
		
		try{
				
			Scanner sc = new Scanner(System.in);
			Socket socket = new Socket("127.0.0.1",3556);
			Scanner sc1= new Scanner(socket.getInputStream());
			System.out.println("Please select from below Options:");
			System.out.println("Press 1 for checking balance.");
			System.out.println("Press 2 for Withdraw.");
			System.out.println("Press 3 for Deposit");
			System.out.println("Press 4 for Exit.");
			
			PrintStream ps = new PrintStream(socket.getOutputStream());
			int userinput= sc.nextInt();
			int amount=0;
			if(userinput==2)
			{
				System.out.println("Please enter withdrawal Amount.");
				amount = sc.nextInt();
			}
			else if(userinput==3)
			{
				System.out.println("Please enter Deposit Amount.");
				amount = sc.nextInt();
			}
			
			ps.println(userinput);
			ps.println(amount);
			String serverOutput = sc1.nextLine();
			System.out.println(serverOutput);
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
	}
}
