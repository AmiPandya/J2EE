var obj = 
        [
            {"id": 1011, "port": "4067", "name": "Volvo","source" :"file","connectiontype":"initial"},
            {"id": 11111, "port": "6789",    "name": "Saab"},
            {"id": 12111, "port": "899",    "name": "Peugeot"},
            {"id": 13111, "port": "9000", "name": "Porsche"},
        
        
            {"id": 20, "color": "black", "name": "Cannondale"},
            {"id": 21, "color": "red",   "name": "Shimano"}
        
        ];


