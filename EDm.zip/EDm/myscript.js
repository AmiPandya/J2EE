 $(document).ready(function(){
	$("#Nav").hide();
	$('ul.tabs li').click(function(){
	var tab_id = $(this).attr('data-tab');
	$('ul.tabs li').removeClass('current');
	$('.tab-content').removeClass('current');
	$(this).addClass('current');
	$("#"+tab_id).addClass('current');
	});

	});
	//Call API for Assignment list
	$.getJSON('https://api.edmodo.com/assignments?access_token=12e7eaf1625004b7341b6d681fa3a7c1c551b5300cf7f7f3a02010e99c84695d', function(data) {
	var x = "";
	for(i in data){
	$("ul").first().append('<li><a id = "'+data[i].title+'" name = "'+getFormat(data[i].due_at)+'" onclick = getId('+data[i].id +',id,name)>'+data[i].title+'<br>'+ "due "+ getFormat(data[i].due_at)+'</a></li></br>');}
	});
	
	//For Specific Assignmnet Details 
	function getId(id , x ,name)
	{
		location.hash = id;// Fragment URL
		$("#Select").hide();
		$("#Nav").show();
		document.getElementById("tab-2").innerHTML = "";
		//URL to call details of every Assignment Id
		var url = "https://api.edmodo.com/assignment_submissions?assignment_id="+ id+"&assignment_creator_id=73240721&access_token=12e7eaf1625004b7341b6d681fa3a7c1c551b5300cf7f7f3a02010e99c84695d";
		$.getJSON(url ,function(data){
		// Set Details for Each Assignmnet in Tabs
			document.getElementById("Assignment_title").innerHTML = x;
			document.getElementById("duedate").innerHTML = name;
			document.getElementById("Assignment_Details").innerHTML = data[0].content;
		
		//Iterate through All the Submission and display their details
		for(i in data){
		$("#tab-2").append('<div class="panel-group" id="accordion">'
		+'<div class="panel panel-default">'
		+'<div class="panel-heading">'
		+'<div id = "img"  ><img src ="'+data[i].creator.avatars.large+'"</div>'
		+'<h4 class="panel-title" margin: 0px>'
		+' <a data-toggle="collapse" data-parent="#accordion" href="#'+i+'">'
		+ data[i].creator.first_name+" "+data[i].creator.last_name+"<br>"+getFormat(data[i].submitted_at)+'</a></h4></div>'
		+'<div id='+i+' class="panel-collapse collapse">'
		+' <div class="panel-body"><h5>'+ data[i].content+'</h5></div></div></div></div>');
		}
		});

	}
	// Date format 
	function getFormat(due_at)
	{
	var x;
	var monthNames = ["January", "February", "March", "April", "May", "June",
	"July", "August", "September", "October", "November", "December"
	];
	var d = new Date(due_at);
	x =  monthNames[d.getMonth()] + " "+ d.getDate() + " , "+ d.getFullYear();
	return x;
	}
	
	
