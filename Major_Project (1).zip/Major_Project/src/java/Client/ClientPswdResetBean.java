/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Client;

/**
 *
 * @author Vatsal
 */
public class ClientPswdResetBean {
     private String cuid, password, email, passjava;
    private boolean valid, session;
                                                    
    /**
     * @return the cuid
     */
    public String getCuid() {
        return cuid;
    }

    /**
     * @param cuid the cuid to set
     */
    public void setCuid(String cuid) {
        this.cuid = cuid;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the passjava
     */
    public String getPassjava() {
        return passjava;
    }

    /**
     * @param passjava the passjava to set
     */
    public void setPassjava(String passjava) {
        this.passjava = passjava;
    }

    /**
     * @return the valid
     */
    public boolean isValid() {
        return valid;
    }

    /**
     * @param valid the valid to set
     */
    public void setValid(boolean valid) {
        this.valid = valid;
    }

    /**
     * @return the session
     */
    public boolean isSession() {
        return session;
    }

    /**
     * @param session the session to set
     */
    public void setSession(boolean session) {
        this.session = session;
    }

    /**
     * @return the buid
     */
   
    
}
